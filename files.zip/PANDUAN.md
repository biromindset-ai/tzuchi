# Login email + password untuk dasbor Tzu Chi (gratis, tanpa kartu, tanpa Google Cloud)

Email yang diizinkan ada di `wrangler.jsonc` → `ALLOWED_EMAILS`. Password disimpan sebagai **secret**
di Cloudflare (bukan di file Drive dan bukan di index.html).

## Struktur repo GitHub
```
wrangler.jsonc
src/worker.js
public/index.html   ← dasbor Anda (potongan login lama sudah dibuang)
```

## Pasang
1. Push struktur di atas ke repo GitHub, deploy sebagai Worker di Cloudflare.
2. *Settings → Variables and Secrets* (tipe **runtime**):
   - `APP_PASSWORD` (Secret) = password bersama, disarankan ≥ 16 karakter (frasa panjang lebih baik)
   - `SESSION_SECRET` (Secret) = teks acak ≥ 32 karakter
3. *Domains & Routes* → custom domain `tzuchi.biromindset.com`.
4. Uji di jendela incognito: tanpa login hanya form yang muncul; salah email/password ditolak; benar → dasbor (sesi 12 jam).
   Keluar: buka `/auth/logout`.

Ganti password: ubah `APP_PASSWORD` lalu deploy ulang (sesi lama tetap berlaku sampai habis;
ubah `SESSION_SECRET` juga bila ingin semua sesi langsung keluar).

## Batasan (jujur)
- Email hanya daftar putih nama; tidak diverifikasi kepemilikannya. Perlindungan utamanya adalah **password**.
  Siapa pun yang tahu password dan salah satu email yang terdaftar bisa masuk.
- Tidak ada pembatasan percobaan selain jeda 1 detik per kegagalan, jadi pakai password panjang.
- Data dasbor masih dibaca dari Google Sheet "siapa saja dengan link" dan Apps Script. Gerbang ini
  melindungi halaman, bukan sheet-nya. Jangan bagikan link sheet.
